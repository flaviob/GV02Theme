        </div>
      </div>
    </div>
    <footer id="colophon" class="site-footer" role="contentinfo">
      <div class="container">
        <div class="site-info" itemscope itemtype="http://schema.org/Organization" rel="nofollow">


          <div class="contacts"> 
            <i class="fa fa-map-marker"></i> Itinerium - Web Content, Lda<br />
              <i class="fa fa-envelope-o"></i> <a href="/contacto" rel="nofollow">Contacto</a><br />
              <i class="fa fa-twitter"></i> <a class="twitter" href="http://twitter.com/guiajando" rel="nofollow">@guiajando</a>
          </div>  
         

        <img itemprop="logo" src="<?php echo get_stylesheet_directory_uri(); ?>/guiajando-white.png" alt="" />
        <p>
          <a href="http://www.guiajando.com/" target="_blank" title="Guia de viajes Guiajando.com">Tours Guiajando</a> (<a href="http://www.newyorkando.com" title="Nueva York" target="_blank">Nueva York</a> - <a href="http://www.londresando.com" title="Londres" target="_blank">Londres</a> - <a href="http://www.parisando.com" title="París" target="_blank">París</a>)<br />
          <a href="/politica-de-privacidad/" rel="nofollow">Política de Privacidad</a>
          <br /><a href="http://www.romando.org" itemprop="url" rel="nofollow">Romando.org</a><br />
          © <?php auto_copyright('2014'); ?> Guia de Roma.
        </p>
      </div>
    </div>
  </footer>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>