jQuery(document).ready(function($){
  $('.current_page_item > a').removeAttr( 'href' );
});